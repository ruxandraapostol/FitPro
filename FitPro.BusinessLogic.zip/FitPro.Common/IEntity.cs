﻿namespace FitPro.Common
{
    public interface IEntity
    {
    }
}
