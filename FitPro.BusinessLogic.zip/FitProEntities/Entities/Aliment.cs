﻿using FitPro.Common;
using System;
using System.Collections.Generic;


namespace FitPro.Entities
{
    public partial class Aliment : IEntity
    {
        public Aliment()
        {
            AlimentRecipes = new HashSet<AlimentRecipe>();
            AlimentRegularUsers = new HashSet<AlimentRegularUser>();
        }

        public Guid IdAliment { get; set; }
        public string Name { get; set; }
        public int Calories { get; set; }
        public int Protein { get; set; }
        public int Fat { get; set; }
        public int Carbo { get; set; }

        public virtual ICollection<AlimentRecipe> AlimentRecipes { get; set; }
        public virtual ICollection<AlimentRegularUser> AlimentRegularUsers { get; set; }
    }
}
