﻿using FitPro.Common;
using System;
using System.Collections.Generic;

#nullable disable

namespace FitPro.Entities
{
    public partial class Recipe : IEntity
    {
        public Recipe()
        {
            AlimentRecipes = new HashSet<AlimentRecipe>();
            Recommandations = new HashSet<Recommandation>();
        }

        public Guid IdRecipe { get; set; }
        public string Preparation { get; set; }
        public Guid? IdCategory { get; set; }

        public virtual CategoryR IdCategoryNavigation { get; set; }
        public virtual ICollection<AlimentRecipe> AlimentRecipes { get; set; }
        public virtual ICollection<Recommandation> Recommandations { get; set; }
    }
}
