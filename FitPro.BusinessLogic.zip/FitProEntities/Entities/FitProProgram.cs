﻿using FitPro.Common;
using System;
using System.Collections.Generic;

#nullable disable

namespace FitPro.Entities
{
    public partial class FitProProgram : IEntity
    {
        public FitProProgram()
        {
            FitProProgramWorkouts = new HashSet<FitProProgramWorkout>();
            RegularUserFitProPrograms = new HashSet<RegularUserFitProProgram>();
        }

        public Guid IdProgram { get; set; }
        public int TimePeriod { get; set; }
        public Guid IdCategory { get; set; }

        public virtual CategoryW IdCategoryNavigation { get; set; }
        public virtual ICollection<FitProProgramWorkout> FitProProgramWorkouts { get; set; }
        public virtual ICollection<RegularUserFitProProgram> RegularUserFitProPrograms { get; set; }
    }
}
