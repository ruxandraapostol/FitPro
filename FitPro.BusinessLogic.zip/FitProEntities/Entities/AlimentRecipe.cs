﻿using FitPro.Common;
using System;

namespace FitPro.Entities
{
    public partial class AlimentRecipe : IEntity
    {
        public Guid IdAliment { get; set; }
        public Guid IdRecipe { get; set; }
        public int Quantity { get; set; }

        public virtual Aliment IdAlimentNavigation { get; set; }
        public virtual Recipe IdRecipeNavigation { get; set; }
    }
}
