﻿using FitPro.Common;
using System;
using System.Collections.Generic;

#nullable disable

namespace FitPro.Entities
{
    public partial class Role : IEntity
    {
        public Role()
        {
            SpecialUsers = new HashSet<SpecialUser>();
        }

        public Guid IdRole { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public virtual ICollection<SpecialUser> SpecialUsers { get; set; }
    }
}
