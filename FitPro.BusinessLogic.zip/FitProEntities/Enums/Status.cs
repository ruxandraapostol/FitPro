﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FitPro.Entities
{
    public enum Status : int
    {
        Pending = 1,
        Accepted = 2,
        Denied = 3,
        Deleted = 4,
    }
}
