﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FitPro.Entities
{
    public enum Gender : int
    {
        Man = 1,
        Woman = 2,
        Anonym = 3,
        Another = 4
    }
}
