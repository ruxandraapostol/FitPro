﻿using FitPro.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FitPro.DataAccess
{
    public class AlimentRecipeConfiguration : IEntityTypeConfiguration<AlimentRecipe>
    {
        public void Configure(EntityTypeBuilder<AlimentRecipe> entity)
        {
            entity.HasKey(e => new { e.IdAliment, e.IdRecipe })
                    .HasName("PK__Aliment-__66906F823A032769");

            entity.ToTable("Aliment-Recipe");

            entity.HasOne(d => d.IdAlimentNavigation)
                .WithMany(p => p.AlimentRecipes)
                .HasForeignKey(d => d.IdAliment)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AR_Aliment");

            entity.HasOne(d => d.IdRecipeNavigation)
                .WithMany(p => p.AlimentRecipes)
                .HasForeignKey(d => d.IdRecipe)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AR_Recipe");
        }
    }
}