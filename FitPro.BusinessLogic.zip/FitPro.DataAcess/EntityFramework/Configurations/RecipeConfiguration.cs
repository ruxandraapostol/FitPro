﻿using FitPro.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FitPro.DataAccess
{
    public class RecipeConfiguration : IEntityTypeConfiguration<Recipe>
    {
        public void Configure(EntityTypeBuilder<Recipe> entity)
        {
            entity.HasKey(e => e.IdRecipe)
                     .HasName("PK__Recipe__2FEC16D4E01A7864");

            entity.ToTable("Recipe");

            entity.Property(e => e.IdRecipe).ValueGeneratedNever();

            entity.Property(e => e.Preparation).IsRequired();

            entity.HasOne(d => d.IdCategoryNavigation)
                .WithMany(p => p.Recipes)
                .HasForeignKey(d => d.IdCategory)
                .HasConstraintName("FK_RecipeCategory");
        }
    }
}