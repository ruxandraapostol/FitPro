﻿using FitPro.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FitPro.DataAccess
{
    public class RecommandationConfiguration : IEntityTypeConfiguration<Recommandation>
    {
        public void Configure(EntityTypeBuilder<Recommandation> entity)
        {
            entity.HasKey(e => new { e.IdFromUser, e.IdToUser, e.IdWorkout, e.IdRecipe })
                    .HasName("PK__Recomman__336E546A56256855");

            entity.ToTable("Recommandation");

            entity.Property(e => e.SendDate).HasColumnType("date");

            entity.HasOne(d => d.IdFromUserNavigation)
                .WithMany(p => p.RecommandationIdFromUserNavigations)
                .HasForeignKey(d => d.IdFromUser)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RecommandationFromRegularUser");

            entity.HasOne(d => d.IdRecipeNavigation)
                .WithMany(p => p.Recommandations)
                .HasForeignKey(d => d.IdRecipe)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RecommandationRecipe");

            entity.HasOne(d => d.IdToUserNavigation)
                .WithMany(p => p.RecommandationIdToUserNavigations)
                .HasForeignKey(d => d.IdToUser)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RecommandationToRegularUser");

            entity.HasOne(d => d.IdWorkoutNavigation)
                .WithMany(p => p.Recommandations)
                .HasForeignKey(d => d.IdWorkout)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_RecommandationWorkout");
        }
    }
}