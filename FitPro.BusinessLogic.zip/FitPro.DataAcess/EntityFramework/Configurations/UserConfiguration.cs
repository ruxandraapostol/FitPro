﻿using FitPro.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FitPro.DataAccess
{
    public class UserConfiguration : IEntityTypeConfiguration<User>
    {
        public void Configure(EntityTypeBuilder<User> entity)
        {
            entity.HasKey(e => e.IdUser)
                    .HasName("PK__User__B7C926383F28A9F6");

            entity.ToTable("User");

            entity.HasIndex(e => e.Email, "UQ__User__A9D1053492FF36C1")
                .IsUnique();

            entity.Property(e => e.IdUser).ValueGeneratedNever();

            entity.Property(e => e.Email)
                .IsRequired()
                .HasMaxLength(200);

            entity.Property(e => e.FirstName)
                .IsRequired()
                .HasMaxLength(200);

            entity.Property(e => e.LastName)
                .IsRequired()
                .HasMaxLength(200);

            entity.Property(e => e.Password)
                .IsRequired()
                .HasMaxLength(500);

            entity.Property(e => e.UserName)
                .IsRequired()
                .HasMaxLength(200);
        }
    }
}
