﻿using Microsoft.AspNetCore.Mvc;
using FitPro.Common.DTOs;

namespace FitPro.WebApp
{
    public class BaseController : Controller
    {
        protected readonly CurrentUserDto CurrentUser;

        public BaseController(ControllerDependencies dependencies)
            : base()
        {
            CurrentUser = dependencies.CurrentUser;
        }
    }
}
