﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using FitPro.BusinessLogic;
using FitPro.Common.DTOs;
using System;
using System.Linq;

namespace FitPro.WebApp
{
    public static class ServiceCollectionExtensionMethods
    {
        public static IServiceCollection AddFitProBusinessLogic(this IServiceCollection services)
        {
            services.AddScoped<RegularUserAccountService>();

            return services;
        }
    }
}
