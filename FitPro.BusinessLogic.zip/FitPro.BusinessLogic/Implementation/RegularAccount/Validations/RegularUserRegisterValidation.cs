﻿using FluentValidation;
using FluentValidator;

namespace FitPro.BusinessLogic
{
    public class RegularUserRegisterValidation : AbstractValidator<RegularRegisterModel>
    {
    }
}
