﻿using System;

namespace FitPro.BusinessLogic
{
    public class RegularRegisterModel
    {
        public string Email { get; set; }

        public string UserName { get; set; }
        public string Password { get; set; }

        public string ConfirmPassword { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime BirthDay { get; set; }
        public int Weight { get; set; }
        public int Height { get; set; }
        public int GenderId { get; set; }
        public int Streak { get; set; } 
    }
}
