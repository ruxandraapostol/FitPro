﻿using System.Collections.Generic;
using System.Linq;

namespace FitPro.BusinessLogic
{
    public class RegularUserAccountService : BaseService
    {
        private readonly RegularUserRegisterValidation RegularUserValidator;
        public RegularUserAccountService(ServiceDependencies dependencies) : base(dependencies)
        {
        }

        public List<string> getUsers()
        {
            return UnitOfWork.Users.Get()
                .Select(u => u.UserName)
                .ToList();
        }
    }
}
